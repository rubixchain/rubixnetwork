echo "IPFS V6 Installer"
user=$(whoami)
sudo rm -r /home/$user/.ipfs
sudo rm /usr/bin/ipfs
echo "Downloading..."
wget https://dist.ipfs.io/go-ipfs/v0.6.0/go-ipfs_v0.6.0_linux-amd64.tar.gz
echo "Unpacking..."
tar -xvf go-ipfs_v0.6.0_linux-amd64.tar.gz
cd go-ipfs
echo "Installing..."
chmod +x install.sh
sudo ./install.sh
cd ..
IPFS_PATH=/home/$user/.ipfs ipfs init
cp -R swarm.key /home/$user/.ipfs
IPFS_PATH=/home/$user/.ipfs ipfs bootstrap rm --all 
IPFS_PATH=/home/$user/.ipfs ipfs bootstrap add /ip4/183.82.0.114/tcp/4001/ipfs/QmcjERi3TqKfLdQp4ViSPMyfGj9oxWKZRAprkppxQc2uMm
IPFS_PATH=/home/$user/.ipfs ipfs config --json Experimental.Libp2pStreamMounting true
IPFS_PATH=/home/$user/.ipfs ipfs config --json Swarm.EnableAutoRelay true
IPFS_PATH=/home/$user/.ipfs ipfs config --json Swarm.EnableRelayHop true
echo "Cleaning..."
rm -r go-ipfs/  go-ipfs_v0.6.0_linux-amd64.tar.gz
